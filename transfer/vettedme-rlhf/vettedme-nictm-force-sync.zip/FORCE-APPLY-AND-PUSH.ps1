﻿# VettedME - FORCE update branch from sync pack and push
$ErrorActionPreference = "Stop"
$Repo = "C:\Users\Henry Okojie\Documents\vettedme-backend"
$Work = $PSScriptRoot
if (-not $Work) { $Work = (Get-Location).Path }
if (-not (Test-Path $Repo)) { throw ("Repo not found at " + $Repo) }
$Bundle = Join-Path $Work "vettedme-nictm-viva-full.bundle"
if (-not (Test-Path $Bundle)) { throw "Bundle missing: vettedme-nictm-viva-full.bundle" }
Set-Location $Repo
git fetch origin
git checkout main
git pull origin main
Write-Host "Force-importing cursor/nictm-viva-validation-8175 ..."
git fetch $Bundle "+HEAD:cursor/nictm-viva-validation-8175"
git checkout cursor/nictm-viva-validation-8175
$MigSrc = Join-Path $Work "prisma\migrations\20260812164741_init_uromi_trust_infrastructure"
$MigDstRoot = Join-Path $Repo "prisma\migrations"
$MigDst = Join-Path $MigDstRoot "20260812164741_init_uromi_trust_infrastructure"
if (Test-Path $MigSrc) {
  New-Item -ItemType Directory -Force -Path $MigDstRoot | Out-Null
  if (Test-Path $MigDst) { Remove-Item -Recurse -Force $MigDst }
  Copy-Item -Recurse -Force $MigSrc $MigDst
  $LockSrc = Join-Path $Work "prisma\migrations\migration_lock.toml"
  if (Test-Path $LockSrc) { Copy-Item -Force $LockSrc (Join-Path $MigDstRoot "migration_lock.toml") }
  git add -f "prisma/migrations/20260812164741_init_uromi_trust_infrastructure"
  if (Test-Path (Join-Path $MigDstRoot "migration_lock.toml")) { git add -f "prisma/migrations/migration_lock.toml" }
  if (git status --porcelain) { git commit -m "chore(prisma): force-track init_uromi_trust_infrastructure migration" }
}
npm install --legacy-peer-deps
npx prisma generate
Write-Host "Force-pushing to GitHub..."
git push -u origin cursor/nictm-viva-validation-8175 --force-with-lease
Write-Host "DONE - tip should be feat(uromi): complete ToT auth, STT viva path, Command Center login"
