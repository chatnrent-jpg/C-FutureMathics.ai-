# VettedME NICTM / Uromi full sync

Litterbox: https://litter.catbox.moe/b7b1mv.zip

One-shot PowerShell (run in Windows PowerShell):

```powershell
$ZipUrl = "https://litter.catbox.moe/b7b1mv.zip"
$Work = "$env:TEMP\vettedme-nictm-sync"
New-Item -ItemType Directory -Force -Path $Work | Out-Null
Invoke-WebRequest -Uri $ZipUrl -OutFile "$Work\sync.zip"
Expand-Archive -Path "$Work\sync.zip" -DestinationPath $Work -Force
& "$Work\APPLY-AND-PUSH.ps1"
```

Pushes branch `cursor/nictm-viva-validation-8175` to `chatnrent-jpg/vettedme-backend`.
