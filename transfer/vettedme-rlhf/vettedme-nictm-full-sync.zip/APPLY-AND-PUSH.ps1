﻿# VettedME - apply this sync pack and push to GitHub
# Repo expected at: C:\Users\Henry Okojie\Documents\vettedme-backend

$ErrorActionPreference = "Stop"
$Repo = "C:\Users\Henry Okojie\Documents\vettedme-backend"
$Work = $PSScriptRoot
if (-not $Work) { $Work = (Get-Location).Path }

if (-not (Test-Path $Repo)) {
  throw ("Repo not found at " + $Repo + " - clone chatnrent-jpg/vettedme-backend first.")
}

$Bundle = Join-Path $Work "vettedme-nictm-viva-full.bundle"
if (-not (Test-Path $Bundle)) {
  throw "Bundle missing next to this script: vettedme-nictm-viva-full.bundle"
}

Set-Location $Repo
Write-Host "Updating main..."
git fetch origin
git checkout main
git pull origin main

Write-Host "Importing cursor/nictm-viva-validation-8175 ..."
git fetch $Bundle HEAD:cursor/nictm-viva-validation-8175
git checkout cursor/nictm-viva-validation-8175

# Force-add Uromi migration (prisma/migrations is gitignored in this repo)
$MigSrc = Join-Path $Work "prisma\migrations\20260812164741_init_uromi_trust_infrastructure"
$MigDstRoot = Join-Path $Repo "prisma\migrations"
$MigDst = Join-Path $MigDstRoot "20260812164741_init_uromi_trust_infrastructure"
if (Test-Path $MigSrc) {
  New-Item -ItemType Directory -Force -Path $MigDstRoot | Out-Null
  if (Test-Path $MigDst) { Remove-Item -Recurse -Force $MigDst }
  Copy-Item -Recurse -Force $MigSrc $MigDst
  $LockSrc = Join-Path $Work "prisma\migrations\migration_lock.toml"
  if (Test-Path $LockSrc) {
    Copy-Item -Force $LockSrc (Join-Path $MigDstRoot "migration_lock.toml")
  }
  git add -f "prisma/migrations/20260812164741_init_uromi_trust_infrastructure"
  if (Test-Path (Join-Path $MigDstRoot "migration_lock.toml")) {
    git add -f "prisma/migrations/migration_lock.toml"
  }
  if (git status --porcelain) {
    git commit -m "chore(prisma): force-track init_uromi_trust_infrastructure migration"
  }
}

Write-Host "npm install + prisma generate..."
npm install --legacy-peer-deps
npx prisma generate

Write-Host "Pushing to GitHub: chatnrent-jpg/vettedme-backend ..."
git push -u origin cursor/nictm-viva-validation-8175

Write-Host ""
Write-Host "DONE - VettedME is on GitHub: cursor/nictm-viva-validation-8175"
Write-Host "Optional local DB: npx prisma migrate deploy ; npx prisma db seed"
