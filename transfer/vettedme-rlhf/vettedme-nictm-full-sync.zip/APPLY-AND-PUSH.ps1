# VettedME — apply full NICTM/Uromi sync pack and push to GitHub
# Repo: C:\Users\Henry Okojie\Documents\vettedme-backend

$ErrorActionPreference = "Stop"
$Repo = "C:\Users\Henry Okojie\Documents\vettedme-backend"
$ZipUrl = "https://litter.catbox.moe/odvzu6.zip"

$Work = Join-Path $env:TEMP "vettedme-nictm-sync"
if (Test-Path $Work) { Remove-Item -Recurse -Force $Work }
New-Item -ItemType Directory -Path $Work | Out-Null

$Zip = Join-Path $Work "sync.zip"
Write-Host "Downloading VettedME sync pack..."
Invoke-WebRequest -Uri $ZipUrl -OutFile $Zip
Expand-Archive -Path $Zip -DestinationPath $Work -Force

if (-not (Test-Path $Repo)) {
  throw "Repo not found at $Repo — clone vettedme-backend first."
}

Set-Location $Repo
git fetch origin
git checkout main
git pull origin main

$Bundle = Join-Path $Work "vettedme-nictm-viva-full.bundle"
if (-not (Test-Path $Bundle)) {
  throw "Bundle missing: vettedme-nictm-viva-full.bundle"
}

Write-Host "Importing cursor/nictm-viva-validation-8175 from bundle..."
# Bundle advertises HEAD tip; map it onto the feature branch name
git fetch $Bundle HEAD:cursor/nictm-viva-validation-8175
git checkout cursor/nictm-viva-validation-8175

# Force-add Uromi migration (prisma/migrations is gitignored)
$MigSrc = Join-Path $Work "prisma\migrations\20260812164741_init_uromi_trust_infrastructure"
$MigDstRoot = Join-Path $Repo "prisma\migrations"
$MigDst = Join-Path $MigDstRoot "20260812164741_init_uromi_trust_infrastructure"
if (Test-Path $MigSrc) {
  New-Item -ItemType Directory -Force -Path $MigDstRoot | Out-Null
  if (Test-Path $MigDst) { Remove-Item -Recurse -Force $MigDst }
  Copy-Item -Recurse -Force $MigSrc $MigDst
  $LockSrc = Join-Path $Work "prisma\migrations\migration_lock.toml"
  if (Test-Path $LockSrc) {
    Copy-Item -Force $LockSrc (Join-Path $MigDstRoot "migration_lock.toml")
  }
  git add -f "prisma/migrations/20260812164741_init_uromi_trust_infrastructure"
  if (Test-Path (Join-Path $MigDstRoot "migration_lock.toml")) {
    git add -f "prisma/migrations/migration_lock.toml"
  }
  if (git status --porcelain) {
    git commit -m "chore(prisma): force-track init_uromi_trust_infrastructure migration"
  }
}

Write-Host "npm install + prisma generate..."
npm install --legacy-peer-deps
npx prisma generate

Write-Host "Pushing to GitHub: chatnrent-jpg/vettedme-backend ..."
git push -u origin cursor/nictm-viva-validation-8175

Write-Host ""
Write-Host "DONE — VettedME branch is on GitHub: cursor/nictm-viva-validation-8175"
Write-Host "Optional: npx prisma migrate deploy ; npx prisma db seed"
