# NICTM viva Zod validation

```powershell
$Zip = "$HOME\Downloads\vettedme-nictm-viva-validation.zip"
Invoke-WebRequest -Uri "REPLACE_URL" -OutFile $Zip
cd "$HOME\Documents\vettedme-backend"
git checkout -B cursor/nictm-viva-validation-8175 origin/cursor/rlhf-calibration-analytics-8175
Expand-Archive -Path $Zip -DestinationPath . -Force
git add src/modules/rlhf-core-rubric/validation.ts
git commit -m "feat(rlhf): add NICTM department + startVivaSession Zod schemas"
git push -u origin cursor/nictm-viva-validation-8175
```
