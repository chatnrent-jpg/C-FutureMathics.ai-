# Apply supervisor analytics route

Endpoint: GET /api/v1/modules/rlhf-core-rubric/analytics (Bearer ADMIN)

```powershell
$Zip = "$HOME\Downloads\vettedme-analytics-route.zip"
Invoke-WebRequest -Uri "REPLACE_URL" -OutFile $Zip
cd "$HOME\Documents\vettedme-backend"
git checkout cursor/rlhf-calibration-analytics-8175
Expand-Archive -Path $Zip -DestinationPath . -Force
git add src/modules/rlhf-core-rubric/controller.ts src/modules/rlhf-core-rubric/routes.ts
git commit -m "feat(rlhf): mount supervisor analytics at GET /analytics"
git push origin cursor/rlhf-calibration-analytics-8175
```
