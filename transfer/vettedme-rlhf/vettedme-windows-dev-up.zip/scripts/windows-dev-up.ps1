# One-shot Windows local unblock for VettedME Uromi stack
# Run in PowerShell from anywhere.

$ErrorActionPreference = "Stop"
$Repo = "C:\Users\Henry Okojie\Documents\vettedme-backend"

if (-not (Test-Path $Repo)) {
  throw "Repo not found: $Repo"
}

Set-Location $Repo

Write-Host "==> Writing .env (PORT 8080, CORS localhost:3000)"
@'
DATABASE_URL="postgresql://vetted_user:vetted_password@127.0.0.1:5432/vetted_db?schema=public"
NODE_ENV="development"
PORT=8080
JWT_SECRET="dev-local-jwt-secret-change-me"
CORS_ORIGIN="http://localhost:3000"
ENCRYPTION_KEY="0123456789abcdef0123456789abcdef"
'@ | Set-Content -Encoding ascii .env

Write-Host "==> Ensuring Postgres is up (Docker)"
$docker = Get-Command docker -ErrorAction SilentlyContinue
if (-not $docker) {
  throw "Docker Desktop is not installed/running. Install Docker Desktop, start it, then re-run this script."
}

$existing = docker ps -a --filter "name=vetted-pg" --format "{{.Names}}"
if ($existing -eq "vetted-pg") {
  $running = docker ps --filter "name=vetted-pg" --format "{{.Names}}"
  if ($running -ne "vetted-pg") {
    docker start vetted-pg | Out-Null
  }
} else {
  docker run -d --name vetted-pg `
    -e POSTGRES_USER=vetted_user `
    -e POSTGRES_PASSWORD=vetted_password `
    -e POSTGRES_DB=vetted_db `
    -p 5432:5432 `
    postgres:16 | Out-Null
}

Write-Host "==> Waiting for Postgres to accept connections..."
$ready = $false
for ($i = 0; $i -lt 30; $i++) {
  docker exec vetted-pg pg_isready -U vetted_user -d vetted_db 2>$null | Out-Null
  if ($LASTEXITCODE -eq 0) { $ready = $true; break }
  Start-Sleep -Seconds 2
}
if (-not $ready) { throw "Postgres did not become ready in time." }

Write-Host "==> prisma generate / migrate / seed"
npm install --legacy-peer-deps
npx prisma generate
npx prisma migrate deploy
npx prisma db seed

Write-Host ""
Write-Host "DB READY. Starting backend on 8080 in this window..."
Write-Host "Keep this window open. In another window start frontend:"
Write-Host '  cd "C:\Users\Henry Okojie\Documents\vettedme-backend\frontend"'
Write-Host "  npm run dev"
Write-Host ""

$env:PORT = "8080"
npx tsx watch src/index.ts
