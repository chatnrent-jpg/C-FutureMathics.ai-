import OpenAI from 'openai';
import { logger } from '../../utils/logger';

export interface AuditorTurnInput {
  systemPrompt: string;
  failureCaseTitle: string;
  modelOutputAnomaly: string;
  expectedRaterAction: string;
  candidateName: string;
  defenseText: string;
  priorHistory: Array<{ sender: string; text: string }>;
}

export interface AuditorTurnResult {
  pushback: string;
  mode: 'openai' | 'deterministic_fallback';
  model?: string;
}

export interface OpeningChallengeInput {
  systemPrompt: string;
  failureCaseTitle: string;
  modelOutputAnomaly: string;
  expectedRaterAction: string;
  candidateName: string;
  rollingMaeScore: number;
  toneAnchor: string;
}

let client: OpenAI | null = null;

function getClient(): OpenAI | null {
  if (!process.env.OPENAI_API_KEY) {
    return null;
  }
  if (!client) {
    client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }
  return client;
}

/**
 * Deterministic alignment score in [-10, +10] from lexical overlap
 * against expected rater action + anomaly tokens (no Math.random).
 * Prefers technical tokens (length >= 5) so boilerplate ("must","rater") does not dilute signal.
 */
export function scoreDefenseAlignment(
  defenseText: string,
  expectedRaterAction: string,
  modelOutputAnomaly: string
): number {
  const tokenize = (s: string): string[] =>
    s
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, ' ')
      .split(/\s+/)
      .filter((t) => t.length >= 5);

  const stop = new Set([
    'rater',
    'must',
    'should',
    'would',
    'their',
    'there',
    'about',
    'model',
    'output',
    'despite',
    'appearance',
    'generated',
    'creating',
    'potential',
  ]);

  const defense = new Set(tokenize(defenseText).filter((t) => !stop.has(t)));
  const need = [
    ...new Set(
      [...tokenize(expectedRaterAction), ...tokenize(modelOutputAnomaly)].filter(
        (t) => !stop.has(t)
      )
    ),
  ];
  if (need.length === 0 || defense.size === 0) {
    return -10;
  }
  const hits = need.filter((t) => defense.has(t)).length;
  const ratio = hits / need.length;
  return Number((ratio * 20 - 10).toFixed(2));
}

function buildDeterministicPushback(input: AuditorTurnInput): string {
  const delta = scoreDefenseAlignment(
    input.defenseText,
    input.expectedRaterAction,
    input.modelOutputAnomaly
  );
  const coverage =
    delta >= 5 ? 'partial recognition' : delta >= 0 ? 'weak recognition' : 'near-zero recognition';

  return (
    `Pushback locked to case "${input.failureCaseTitle}". ` +
    `Your defense shows ${coverage} of the required rater action ` +
    `(alignment delta ${delta}). ` +
    `Anomaly under audit: ${input.modelOutputAnomaly} ` +
    `Competent response must: ${input.expectedRaterAction} ` +
    `Defend with concrete thresholds, failure modes, and corrective controls — not generalities.`
  );
}

function buildDeterministicOpening(input: OpeningChallengeInput): string {
  return (
    `${input.toneAnchor} online. Candidate ${input.candidateName}: Tier 1 MAE ${input.rollingMaeScore}. ` +
    `Case study locked — "${input.failureCaseTitle}". ` +
    `Anomaly: ${input.modelOutputAnomaly} ` +
    `Did you catch this in Tier 1? State the reject criteria and the control you would enforce. Now.`
  );
}

/**
 * Opening critique for AUDITOR_CHALLENGE_INIT — OpenAI when keyed, else deterministic case study.
 */
export async function generateAuditorOpening(
  input: OpeningChallengeInput
): Promise<AuditorTurnResult> {
  const openai = getClient();
  if (!openai) {
    return {
      pushback: buildDeterministicOpening(input),
      mode: 'deterministic_fallback',
    };
  }

  try {
    const model = process.env.OPENAI_AUDITOR_MODEL || 'gpt-4o-mini';
    const response = await openai.chat.completions.create({
      model,
      temperature: 0.4,
      max_tokens: 280,
      messages: [
        { role: 'system', content: input.systemPrompt },
        {
          role: 'user',
          content: [
            `Open the Tier 2 viva. Candidate: ${input.candidateName}. MAE: ${input.rollingMaeScore}.`,
            `Failure case: ${input.failureCaseTitle}`,
            `Anomaly: ${input.modelOutputAnomaly}`,
            `Expected competent rater action: ${input.expectedRaterAction}`,
            'Deliver ONE sharp opening challenge (3-5 sentences). No greeting. No markdown.',
          ].join('\n'),
        },
      ],
    });

    const content = response.choices[0]?.message?.content?.trim();
    if (!content) {
      throw new Error('Empty OpenAI opening challenge');
    }

    return { pushback: content, mode: 'openai', model };
  } catch (error) {
    logger.error('Auditor opening LLM failed — deterministic fallback', {
      error: error instanceof Error ? error.message : String(error),
    });
    return {
      pushback: buildDeterministicOpening(input),
      mode: 'deterministic_fallback',
    };
  }
}

/**
 * Critique a candidate defense turn using persona system prompt + case study.
 */
export async function generateAuditorPushback(
  input: AuditorTurnInput
): Promise<AuditorTurnResult> {
  const openai = getClient();
  if (!openai) {
    return {
      pushback: buildDeterministicPushback(input),
      mode: 'deterministic_fallback',
    };
  }

  try {
    const model = process.env.OPENAI_AUDITOR_MODEL || 'gpt-4o-mini';
    const historyMessages = input.priorHistory.slice(-8).map((h) => ({
      role: (h.sender === 'CANDIDATE' ? 'user' : 'assistant') as
        | 'user'
        | 'assistant',
      content: h.text,
    }));

    const response = await openai.chat.completions.create({
      model,
      temperature: 0.5,
      max_tokens: 350,
      messages: [
        { role: 'system', content: input.systemPrompt },
        ...historyMessages,
        {
          role: 'user',
          content: [
            `Candidate defense submission from ${input.candidateName}:`,
            input.defenseText,
            '',
            'Respond as the AI Auditor. Stay locked to the CRITICAL EVALUATION CASE STUDY.',
            'Push back aggressively in 3-6 sentences. Demand specifics. No greeting. No markdown.',
          ].join('\n'),
        },
      ],
    });

    const content = response.choices[0]?.message?.content?.trim();
    if (!content) {
      throw new Error('Empty OpenAI auditor pushback');
    }

    return { pushback: content, mode: 'openai', model };
  } catch (error) {
    logger.error('Auditor pushback LLM failed — deterministic fallback', {
      error: error instanceof Error ? error.message : String(error),
      candidateName: input.candidateName,
    });
    return {
      pushback: buildDeterministicPushback(input),
      mode: 'deterministic_fallback',
    };
  }
}
