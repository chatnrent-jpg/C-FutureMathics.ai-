import { Server as HttpServer, IncomingMessage } from 'http';
import { WebSocketServer, WebSocket, type RawData } from 'ws';
import { Prisma } from '@prisma/client';
import { prisma } from '../../lib/prisma';
import { getAuditorPersona } from './auditorMatrix';
import {
  generateAuditorOpening,
  generateAuditorPushback,
  scoreDefenseAlignment,
} from './auditorLlm';
import { logger } from '../../utils/logger';

interface TranscriptHistoryItem {
  sender: string;
  text: string;
  at?: string;
  mode?: string;
}

interface TranscriptState {
  sessionState: string;
  systemCalibration?: string;
  history: TranscriptHistoryItem[];
  [key: string]: unknown;
}

interface ActiveSession {
  ws: WebSocket;
  candidateId: string;
  evaluationId: string;
  department: string;
  systemPrompt: string;
  failureCaseTitle: string;
  modelOutputAnomaly: string;
  expectedRaterAction: string;
  candidateName: string;
}

// Active memory mapping to manage concurrent connections on the Uromi workshop floor
const activeSessions = new Map<string, ActiveSession>();

function asTranscript(raw: unknown): TranscriptState {
  if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
    const obj = raw as Record<string, unknown>;
    const history = Array.isArray(obj.history)
      ? (obj.history as TranscriptHistoryItem[])
      : [];
    return {
      ...obj,
      sessionState: String(obj.sessionState || 'ACTIVE'),
      history,
    };
  }
  return { sessionState: 'ACTIVE', history: [] };
}

async function appendTranscriptTurn(
  evaluationId: string,
  turns: TranscriptHistoryItem[],
  sessionState: string
): Promise<TranscriptState> {
  const current = await prisma.candidateEvaluation.findUnique({
    where: { id: evaluationId },
    select: { aiAuditorTranscript: true, logicalConsistency: true },
  });

  const transcript = asTranscript(current?.aiAuditorTranscript);
  transcript.sessionState = sessionState;
  transcript.history = [...transcript.history, ...turns];

  await prisma.candidateEvaluation.update({
    where: { id: evaluationId },
    data: {
      aiAuditorTranscript: transcript as Prisma.InputJsonValue,
    },
  });

  return transcript;
}

/**
 * Initializes the Tier 2 Interactive Viva WebSocket server engine.
 * Attaches securely to the primary Express/HTTP server instance.
 */
export function initVivaSocketServer(server: HttpServer) {
  const wss = new WebSocketServer({ noServer: true });

  logger.info(
    '📡 Real-time Tier 2 WebSocket Engine initialized. Monitoring Starlink pipes...'
  );

  // Handle manual HTTP upgrade delegation from Express
  server.on('upgrade', (request, socket, head) => {
    const host = request.headers.host || 'localhost';
    const url = new URL(request.url || '', `http://${host}`);

    if (url.pathname === '/api/rlhf/viva/stream') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
      return;
    }

    // Justice: reject unknown upgrade paths — do not leave the socket half-open
    socket.destroy();
  });

  wss.on('connection', async (ws: WebSocket, request: IncomingMessage) => {
    const host = request.headers.host || 'localhost';
    const url = new URL(request.url || '', `http://${host}`);
    const evaluationId = url.searchParams.get('evaluationId');

    if (!evaluationId) {
      ws.close(4001, 'Missing evaluationId parameter');
      return;
    }

    try {
      // 1. Fetch evaluation context and link it to the candidate's academic department
      const evaluation = await prisma.candidateEvaluation.findUnique({
        where: { id: evaluationId },
        include: { candidate: true, workstation: true },
      });

      if (!evaluation) {
        ws.close(4004, 'Evaluation session record not found');
        return;
      }

      const { candidate, workstation } = evaluation;

      // 2. Generate the dynamic, authoritative AI Auditor persona rules
      const persona = getAuditorPersona(
        candidate.department,
        candidate.fullName,
        evaluation.rollingMaeScore
      );

      // Register the active connection payload into server memory
      activeSessions.set(evaluationId, {
        ws,
        candidateId: candidate.id,
        evaluationId: evaluation.id,
        department: candidate.department,
        systemPrompt: persona.systemPromptTokens,
        failureCaseTitle: persona.failureCaseTitle,
        modelOutputAnomaly: persona.modelOutputAnomaly,
        expectedRaterAction: persona.expectedRaterAction,
        candidateName: candidate.fullName,
      });

      logger.info(
        `⚡ Station ${workstation.stationNumber} connected over pipe: ${workstation.starlinkStreamId}`
      );
      logger.info(
        `🤖 AI Auditor Persona mounted: [${persona.toneAnchor}] targeting ${candidate.fullName}`
      );

      // 3. Opening challenge — LLM when OPENAI_API_KEY set, else deterministic case study
      const opening = await generateAuditorOpening({
        systemPrompt: persona.systemPromptTokens,
        failureCaseTitle: persona.failureCaseTitle,
        modelOutputAnomaly: persona.modelOutputAnomaly,
        expectedRaterAction: persona.expectedRaterAction,
        candidateName: candidate.fullName,
        rollingMaeScore: evaluation.rollingMaeScore,
        toneAnchor: persona.toneAnchor,
      });

      await appendTranscriptTurn(
        evaluation.id,
        [
          {
            sender: 'AUDITOR',
            text: opening.pushback,
            at: new Date().toISOString(),
            mode: opening.mode,
          },
        ],
        'AUDITOR_CHALLENGE_LIVE'
      );

      ws.send(
        JSON.stringify({
          event: 'AUDITOR_CHALLENGE_INIT',
          toneAnchor: persona.toneAnchor,
          critiqueFocus: persona.critiqueFocus,
          failureCaseTitle: persona.failureCaseTitle,
          modelOutputAnomaly: persona.modelOutputAnomaly,
          expectedRaterAction: persona.expectedRaterAction,
          mode: opening.mode,
          message: opening.pushback,
        })
      );

      // 4. Listen for binary audio payloads or real-time defense transcripts
      ws.on('message', async (messageBuffer: RawData, isBinary: boolean) => {
        try {
          if (!isBinary) {
            const text =
              typeof messageBuffer === 'string'
                ? messageBuffer
                : Buffer.isBuffer(messageBuffer)
                  ? messageBuffer.toString('utf8')
                  : Buffer.from(messageBuffer as ArrayBuffer).toString('utf8');

            let data: { event?: string; text?: string };
            try {
              data = JSON.parse(text);
            } catch {
              logger.warn(
                'Rejected non-JSON text frame on viva stream (Justice)'
              );
              return;
            }

            if (data.event === 'CANDIDATE_DEFENSE_SUBMIT') {
              const defenseText = String(data.text || '').trim();
              if (!defenseText) {
                ws.send(
                  JSON.stringify({
                    event: 'AUDITOR_PUSHBACK',
                    mode: 'deterministic_fallback',
                    message:
                      'Empty defense rejected. Submit a concrete technical rationale.',
                  })
                );
                return;
              }

              logger.info(
                `🧠 Processing candidate logical defense: "${defenseText}"`
              );

              // Courage: execute auditor critique immediately (LLM or deterministic)
              const prior = asTranscript(
                (
                  await prisma.candidateEvaluation.findUnique({
                    where: { id: evaluation.id },
                    select: { aiAuditorTranscript: true },
                  })
                )?.aiAuditorTranscript
              );

              const critique = await generateAuditorPushback({
                systemPrompt: persona.systemPromptTokens,
                failureCaseTitle: persona.failureCaseTitle,
                modelOutputAnomaly: persona.modelOutputAnomaly,
                expectedRaterAction: persona.expectedRaterAction,
                candidateName: candidate.fullName,
                defenseText,
                priorHistory: prior.history,
              });

              // Temperance/Justice: deterministic alignment delta — never Math.random
              const logicalConsistencyDelta = scoreDefenseAlignment(
                defenseText,
                persona.expectedRaterAction,
                persona.modelOutputAnomaly
              );

              await prisma.raterTelemetry.create({
                data: {
                  candidateId: candidate.id,
                  actionType: 'LOGIC_REVISION',
                  metricDelta: logicalConsistencyDelta,
                },
              });

              // Rolling logicalConsistency: clamp 0-100 from prior + delta
              const nextConsistency = Math.max(
                0,
                Math.min(100, evaluation.logicalConsistency + logicalConsistencyDelta)
              );
              evaluation.logicalConsistency = nextConsistency;

              await prisma.candidateEvaluation.update({
                where: { id: evaluation.id },
                data: { logicalConsistency: nextConsistency },
              });

              await appendTranscriptTurn(
                evaluation.id,
                [
                  {
                    sender: 'CANDIDATE',
                    text: defenseText,
                    at: new Date().toISOString(),
                  },
                  {
                    sender: 'AUDITOR',
                    text: critique.pushback,
                    at: new Date().toISOString(),
                    mode: critique.mode,
                  },
                ],
                'DEFENSE_EXCHANGE'
              );

              ws.send(
                JSON.stringify({
                  event: 'AUDITOR_PUSHBACK',
                  mode: critique.mode,
                  model: critique.model,
                  alignmentDelta: logicalConsistencyDelta,
                  logicalConsistency: nextConsistency,
                  message: critique.pushback,
                })
              );
            }
            return;
          }

          // Pure binary raw PCM/webm audio from the client headset
          // Next: pipe chunk to speech-to-text, then reuse CANDIDATE_DEFENSE_SUBMIT path
          const byteLen = Buffer.isBuffer(messageBuffer)
            ? messageBuffer.length
            : Buffer.from(messageBuffer as ArrayBuffer).length;
          logger.info(
            `🎙️ Streaming ${byteLen} bytes of raw audio data over Starlink from Candidate: ${candidate.fullName}`
          );
        } catch (err) {
          logger.error('Error handling WebSocket message frame:', err);
          try {
            ws.send(
              JSON.stringify({
                event: 'AUDITOR_ERROR',
                message:
                  'Auditor runtime fault on this frame. Resubmit your defense.',
              })
            );
          } catch {
            /* socket may already be closed */
          }
        }
      });

      ws.on('close', () => {
        logger.info(
          `🛑 Station ${workstation.stationNumber} disconnected. Tearing down stream channels.`
        );
        activeSessions.delete(evaluationId);
      });
    } catch (error) {
      logger.error('Failed to mount socket streaming pipe:', error);
      ws.close(5000, 'Internal runtime socket mapping failure');
    }
  });
}

/** Active duplex sessions on the workshop floor (read-only inspection helpers). */
export function getActiveVivaSessionCount(): number {
  return activeSessions.size;
}
