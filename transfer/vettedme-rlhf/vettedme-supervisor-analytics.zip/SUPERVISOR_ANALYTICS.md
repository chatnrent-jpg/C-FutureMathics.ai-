# Supervisor Admin Analytics

## Endpoint
`GET /api/v1/modules/rlhf-core-rubric/admin/analytics`

## Auth
Bearer JWT with `role: "ADMIN"` (403 for other roles, 401 without token).

## What it returns
- Prisma AI profile fields (`aiStatus`, `aiScore`, `aiFailureReason`, `aiLastAttemptAt`)
- Streamed aggregates from `logs/rlhf-telemetry/rlhf-rater-telemetry.jsonl`
- Per-candidate metrics: pairs evaluated, avg time, speedrun flags, safety hard-fails, pass rate, average absolute drift by dimension (`helpfulness` / `factuality` / `safety` / `tone`), struggling dimensions

## Apply on Windows
```powershell
cd $HOME\Documents\vettedme-backend
git checkout cursor/rlhf-calibration-analytics-8175
Expand-Archive -Path "$HOME\Downloads\vettedme-supervisor-analytics.zip" -DestinationPath . -Force
git add src/modules/rlhf-core-rubric/controller.ts src/modules/rlhf-core-rubric/routes.ts
git commit -m "feat(rlhf): add Supervisor Admin analytics data table API"
git push origin cursor/rlhf-calibration-analytics-8175
```
