'use client';

import React, { useState, useEffect } from 'react';

interface AnalyticsFeed {
  id: string;
  fullName: string;
  department: string;
  currentTier: string;
  rollingMaeScore: number;
  defenseScore: number;
  logicalConsistency?: number;
  supervisorNotes?: string | null;
  isCertified: boolean;
  stationNumber: number;
  rowLocation: string;
}

interface TranscriptTurn {
  sender?: string;
  text?: string;
  at?: string;
  mode?: string;
}

interface VivaDetail {
  id: string;
  fullName: string;
  department: string;
  currentTier: string;
  isCertified: boolean;
  rollingMaeScore: number;
  defenseScore: number;
  logicalConsistency: number;
  supervisorNotes: string | null;
  stationNumber: number;
  rowLocation: string;
  aiAuditorTranscript?: {
    sessionState?: string;
    history?: TranscriptTurn[];
  };
  passRule: {
    defenseScoreMin: number;
    rollingMaeScoreMax: number;
  };
}

export default function SupervisorAnalyticsDashboard() {
  const [metrics, setMetrics] = useState<AnalyticsFeed[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastError, setLastError] = useState<string | null>(null);

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [detail, setDetail] = useState<VivaDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [defenseScore, setDefenseScore] = useState(75);
  const [logicalConsistency, setLogicalConsistency] = useState(50);
  const [supervisorNotes, setSupervisorNotes] = useState('');
  const [signOffBusy, setSignOffBusy] = useState(false);
  const [signOffMessage, setSignOffMessage] = useState<string | null>(null);

  const feedUrl =
    process.env.NEXT_PUBLIC_RLHF_LIVE_FEED_URL ||
    '/api/rlhf/analytics/live-feed';

  const fetchLiveMetrics = async () => {
    try {
      const response = await fetch(feedUrl, { cache: 'no-store' });
      if (!response.ok) {
        setLastError(
          `Live-feed HTTP ${response.status}. Is backend on :8080? (${feedUrl})`
        );
        return;
      }
      const payload = await response.json();
      if (payload.status === 'success' && Array.isArray(payload.data)) {
        setMetrics(payload.data);
        setLastError(null);
      } else {
        setLastError(payload.message || 'Unexpected live-feed payload shape');
      }
    } catch (err) {
      console.error('Failed to stream analytics endpoint data matrix:', err);
      setLastError(
        `Failed to reach live-feed (${feedUrl}). Start backend: $env:PORT=8080; npx tsx watch src/index.ts`
      );
    } finally {
      setLoading(false);
    }
  };

  const loadDetail = async (evaluationId: string) => {
    setSelectedId(evaluationId);
    setDetailLoading(true);
    setSignOffMessage(null);
    try {
      const response = await fetch(`/api/rlhf/viva/${evaluationId}`, {
        cache: 'no-store',
      });
      const payload = await response.json();
      if (!response.ok || payload.status !== 'success') {
        setSignOffMessage(payload.message || `Detail HTTP ${response.status}`);
        setDetail(null);
        return;
      }
      const d = payload.data as VivaDetail;
      setDetail(d);
      setDefenseScore(
        Number.isFinite(d.defenseScore) && d.defenseScore > 0
          ? d.defenseScore
          : 75
      );
      setLogicalConsistency(
        Number.isFinite(d.logicalConsistency) ? d.logicalConsistency : 50
      );
      setSupervisorNotes(d.supervisorNotes || '');
    } catch (err) {
      console.error(err);
      setSignOffMessage('Failed to load evaluation detail.');
      setDetail(null);
    } finally {
      setDetailLoading(false);
    }
  };

  const submitSignOff = async () => {
    if (!selectedId) return;
    setSignOffBusy(true);
    setSignOffMessage(null);
    try {
      const response = await fetch(`/api/rlhf/viva/${selectedId}/evaluate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          defenseScore: Number(defenseScore),
          logicalConsistency: Number(logicalConsistency),
          supervisorNotes: supervisorNotes.trim() || undefined,
        }),
      });
      const payload = await response.json();
      if (!response.ok || payload.status !== 'success') {
        const detailMsg =
          payload.details?.[0] ||
          payload.message ||
          `Evaluate HTTP ${response.status}`;
        setSignOffMessage(detailMsg);
        return;
      }
      setSignOffMessage(payload.message);
      await fetchLiveMetrics();
      await loadDetail(selectedId);
    } catch (err) {
      console.error(err);
      setSignOffMessage('Sign-off request failed — is backend on :8080?');
    } finally {
      setSignOffBusy(false);
    }
  };

  useEffect(() => {
    fetchLiveMetrics();
    const interval = setInterval(fetchLiveMetrics, 5000);
    return () => clearInterval(interval);
  }, []);

  const history = detail?.aiAuditorTranscript?.history || [];
  const wouldPass =
    defenseScore >= 75 && (detail?.rollingMaeScore ?? 1) <= 0.1;

  return (
    <div
      style={{
        padding: '2rem',
        fontFamily:
          'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
        backgroundColor: '#020617',
        color: '#f8fafc',
        minHeight: '100vh',
      }}
    >
      <header
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderBottom: '1px solid #1e293b',
          paddingBottom: '1rem',
          marginBottom: '2rem',
        }}
      >
        <div>
          <h1 style={{ color: '#38bdf8', fontSize: '1.75rem' }}>
            🌅 Uromi Command Center
          </h1>
          <p style={{ fontSize: '0.8rem', color: '#64748b' }}>
            Ugboha Road Facility // Active Session Telemetry Matrix
          </p>
        </div>
        <button
          onClick={fetchLiveMetrics}
          style={{
            backgroundColor: '#1e293b',
            border: '1px solid #334155',
            color: '#38bdf8',
            padding: '0.5rem 1rem',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '0.8rem',
          }}
        >
          ⟳ REFRESH FEED
        </button>
      </header>

      {lastError ? (
        <p style={{ color: '#f87171', marginBottom: '1rem', fontSize: '0.85rem' }}>
          {lastError}
        </p>
      ) : null}

      {loading ? (
        <p style={{ color: '#64748b' }}>Ingesting database pipeline records...</p>
      ) : (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: selectedId ? '1.2fr 1fr' : '1fr',
            gap: '1.5rem',
            alignItems: 'start',
          }}
        >
          <div style={{ overflowX: 'auto' }}>
            <table
              style={{
                width: '100%',
                borderCollapse: 'collapse',
                textAlign: 'left',
                fontSize: '0.85rem',
              }}
            >
              <thead>
                <tr style={{ borderBottom: '2px solid #334155', color: '#94a3b8' }}>
                  <th style={{ padding: '0.75rem' }}>STATION</th>
                  <th style={{ padding: '0.75rem' }}>CANDIDATE</th>
                  <th style={{ padding: '0.75rem' }}>NICTM DEPARTMENT</th>
                  <th style={{ padding: '0.75rem' }}>TIER STATUS</th>
                  <th style={{ padding: '0.75rem' }}>MAE</th>
                  <th style={{ padding: '0.75rem' }}>DEFENSE</th>
                  <th style={{ padding: '0.75rem' }}>STATUS</th>
                </tr>
              </thead>
              <tbody>
                {metrics.map((row) => {
                  const active = selectedId === row.id;
                  return (
                    <tr
                      key={row.id}
                      onClick={() => loadDetail(row.id)}
                      style={{
                        borderBottom: '1px solid #1e293b',
                        backgroundColor: row.isCertified
                          ? '#042f1a'
                          : active
                            ? '#0f172a'
                            : 'transparent',
                        cursor: 'pointer',
                        outline: active ? '1px solid #38bdf8' : 'none',
                      }}
                    >
                      <td
                        style={{
                          padding: '1rem',
                          fontWeight: 'bold',
                          color: '#38bdf8',
                        }}
                      >
                        {row.rowLocation}-{row.stationNumber}
                      </td>
                      <td style={{ padding: '1rem', color: '#fff' }}>
                        {row.fullName}
                      </td>
                      <td style={{ padding: '1rem', color: '#94a3b8' }}>
                        {row.department.replace(/_/g, ' ')}
                      </td>
                      <td style={{ padding: '1rem' }}>
                        <span
                          style={{
                            backgroundColor: '#1e293b',
                            padding: '0.25rem 0.5rem',
                            borderRadius: '4px',
                            fontSize: '0.75rem',
                          }}
                        >
                          {row.currentTier}
                        </span>
                      </td>
                      <td
                        style={{
                          padding: '1rem',
                          color:
                            row.rollingMaeScore <= 0.05 ? '#34d399' : '#f87171',
                        }}
                      >
                        {Number(row.rollingMaeScore).toFixed(3)}
                      </td>
                      <td style={{ padding: '1rem', fontWeight: 'bold' }}>
                        {Number(row.defenseScore).toFixed(1)}%
                      </td>
                      <td style={{ padding: '1rem' }}>
                        {row.isCertified ? (
                          <span style={{ color: '#34d399', fontWeight: 'bold' }}>
                            ✅ CERTIFIED
                          </span>
                        ) : (
                          <span style={{ color: '#64748b' }}>PENDING VIVA</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {metrics.length === 0 ? (
              <p style={{ color: '#64748b', marginTop: '1rem' }}>
                No evaluation rows yet. Run: npx prisma db seed
              </p>
            ) : (
              <p style={{ color: '#64748b', marginTop: '0.75rem', fontSize: '0.75rem' }}>
                Click a row to open ToT transcript review + certification sign-off.
              </p>
            )}
          </div>

          {selectedId ? (
            <aside
              style={{
                backgroundColor: '#0f172a',
                border: '1px solid #1e293b',
                borderRadius: '8px',
                padding: '1.25rem',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  marginBottom: '1rem',
                }}
              >
                <h2 style={{ color: '#38bdf8', fontSize: '1rem', margin: 0 }}>
                  ToT Sign-Off Desk
                </h2>
                <button
                  onClick={() => {
                    setSelectedId(null);
                    setDetail(null);
                    setSignOffMessage(null);
                  }}
                  style={{
                    background: 'transparent',
                    border: '1px solid #334155',
                    color: '#94a3b8',
                    borderRadius: '4px',
                    padding: '0.25rem 0.5rem',
                    cursor: 'pointer',
                    fontSize: '0.75rem',
                  }}
                >
                  CLOSE
                </button>
              </div>

              {detailLoading ? (
                <p style={{ color: '#64748b' }}>Loading transcript ledger...</p>
              ) : detail ? (
                <>
                  <p style={{ fontSize: '0.85rem', marginBottom: '0.5rem' }}>
                    <strong>{detail.fullName}</strong>
                    <span style={{ color: '#64748b' }}>
                      {' '}
                      // {detail.rowLocation}-{detail.stationNumber}
                    </span>
                  </p>
                  <p style={{ fontSize: '0.75rem', color: '#94a3b8', marginBottom: '1rem' }}>
                    MAE {Number(detail.rollingMaeScore).toFixed(3)} · Pass if
                    defense ≥ {detail.passRule.defenseScoreMin} and MAE ≤{' '}
                    {detail.passRule.rollingMaeScoreMax}
                  </p>

                  <div
                    style={{
                      height: '220px',
                      overflowY: 'auto',
                      backgroundColor: '#020617',
                      border: '1px solid #1e293b',
                      borderRadius: '6px',
                      padding: '0.75rem',
                      marginBottom: '1rem',
                      fontSize: '0.8rem',
                    }}
                  >
                    {history.length === 0 ? (
                      <p style={{ color: '#64748b' }}>
                        No auditor transcript turns yet. Candidate must connect
                        via /viva first.
                      </p>
                    ) : (
                      history.map((turn, i) => (
                        <div
                          key={i}
                          style={{
                            marginBottom: '0.65rem',
                            borderLeft: '2px solid #38bdf8',
                            paddingLeft: '0.5rem',
                            color:
                              turn.sender === 'CANDIDATE'
                                ? '#34d399'
                                : '#f1f5f9',
                          }}
                        >
                          <div style={{ color: '#64748b', fontSize: '0.7rem' }}>
                            {turn.sender || 'SYSTEM'}
                            {turn.mode ? ` · ${turn.mode}` : ''}
                          </div>
                          {turn.text}
                        </div>
                      ))
                    )}
                  </div>

                  <label style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
                    Defense score (0–100)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={defenseScore}
                    onChange={(e) => setDefenseScore(Number(e.target.value))}
                    style={{
                      width: '100%',
                      margin: '0.35rem 0 0.75rem',
                      padding: '0.6rem',
                      borderRadius: '4px',
                      border: '1px solid #334155',
                      backgroundColor: '#020617',
                      color: '#fff',
                    }}
                  />

                  <label style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
                    Logical consistency (0–100)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={logicalConsistency}
                    onChange={(e) =>
                      setLogicalConsistency(Number(e.target.value))
                    }
                    style={{
                      width: '100%',
                      margin: '0.35rem 0 0.75rem',
                      padding: '0.6rem',
                      borderRadius: '4px',
                      border: '1px solid #334155',
                      backgroundColor: '#020617',
                      color: '#fff',
                    }}
                  />

                  <label style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
                    Supervisor notes
                  </label>
                  <textarea
                    value={supervisorNotes}
                    onChange={(e) => setSupervisorNotes(e.target.value)}
                    rows={3}
                    placeholder="ToT administrative notes / floor observations..."
                    style={{
                      width: '100%',
                      margin: '0.35rem 0 0.75rem',
                      padding: '0.6rem',
                      borderRadius: '4px',
                      border: '1px solid #334155',
                      backgroundColor: '#020617',
                      color: '#fff',
                      resize: 'vertical',
                    }}
                  />

                  <p
                    style={{
                      fontSize: '0.75rem',
                      color: wouldPass ? '#34d399' : '#f87171',
                      marginBottom: '0.75rem',
                    }}
                  >
                    Preview: {wouldPass ? 'WILL CERTIFY → Tier 3' : 'WILL REMAIN Tier 2'}
                  </p>

                  <button
                    onClick={submitSignOff}
                    disabled={signOffBusy}
                    style={{
                      width: '100%',
                      padding: '0.85rem',
                      fontWeight: 'bold',
                      border: 'none',
                      borderRadius: '6px',
                      cursor: signOffBusy ? 'wait' : 'pointer',
                      backgroundColor: wouldPass ? '#059669' : '#475569',
                      color: '#fff',
                    }}
                  >
                    {signOffBusy ? 'SUBMITTING...' : 'SUBMIT ToT SIGN-OFF'}
                  </button>
                </>
              ) : (
                <p style={{ color: '#f87171' }}>Could not load evaluation.</p>
              )}

              {signOffMessage ? (
                <p
                  style={{
                    marginTop: '0.85rem',
                    fontSize: '0.8rem',
                    color: signOffMessage.toLowerCase().includes('passed')
                      ? '#34d399'
                      : '#94a3b8',
                  }}
                >
                  {signOffMessage}
                </p>
              ) : null}
            </aside>
          ) : null}
        </div>
      )}
    </div>
  );
}
